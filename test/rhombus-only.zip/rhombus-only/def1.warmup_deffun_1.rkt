#lang rhombus

fun f(x, y, z):
    x + (y + z)

f(2, 1, 3)
