#lang rhombus

def x = 12(54)
3
