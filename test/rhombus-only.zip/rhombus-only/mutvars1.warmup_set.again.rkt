#lang rhombus

def mutable discount = 10
discount := 10 + 15
discount
