#lang rhombus

def m = Array(82, 76)
m[0] := m
m[1]
