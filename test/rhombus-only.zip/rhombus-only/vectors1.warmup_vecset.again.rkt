#lang rhombus

def v = Array(83, 64)
v[0] := 66
v
